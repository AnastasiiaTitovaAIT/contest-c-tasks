#ifndef RAND_H_INCLUDED
#define RAND_H_INCLUDED
int
rand_range(int low, int high);
#endif

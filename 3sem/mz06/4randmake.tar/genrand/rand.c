#include <stdio.h>
#include <stdlib.h>
#include "rand.h"
int
rand_range(int low, int high)
{
    return (int)(rand()/(RAND_MAX * 1.0) * (high - low) + low);
}
